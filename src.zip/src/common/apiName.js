const apiName = {
    login: 'user/login',
    BASEURL: 'https://bilalkhanbhati.herokuapp.com/',
    sign: 'user/singup',
    otpverify: 'verify/otp',
    fogetpassword:'Forget/password',
    resetpassword:'reset/password'
};
export default apiName;


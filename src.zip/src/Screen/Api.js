import {
    StyleSheet,
    Text,
    View,
    FlatList,
    Image,
    TouchableOpacity,
  } from 'react-native';
  import React, {useEffect, useState} from 'react';
  import MasonryList from "react-native-masonry-list";  
  const Api = ({navigation}) => {
    // const [data, setdata] = useState([]);
  
    // useEffect(() => {
    //   apicall();
    // }, []);
  
    // const apicall = async () => {
    //   const response = await fetch(
    //     'https://pixabay.com/api/?key=31422245-3aaef51dfc81d975659f460fb&q=yellow+flowers&image_type=photo',
    //   );
    //   const json = await response.json();
    //   setdata(json.hits);
    //   console.log('===', json.hits);
    // };
    // const onclick = data => {
    //   props.navigation.navigate('Api2', {user: data.id});
    //   console.log('====', data);
    // };
  
    // const renderItem = ({item, index}) => {
    //   return (
    //     <TouchableOpacity
    //       onPress={() => navigation.navigate('Api2', {'ImageData': item})}
    //       style={{
         
    //       }}>
    //       <Image
    //         style={{

    //           height:index % 2 == 0 ? 100 : 200,
    //           borderRadius: 20,
         
    //           width: 150,
    //           resizeMode: 'contain',
    //           marginTop: index % 2== -2 ?  -60 : 30,
    //           marginLeft: 10,
    //           alignSelf:'stretch'
    //         }}
    //         source={{uri: item.largeImageURL}}
    //       />
    //     </TouchableOpacity>
    //   );
    // };
    // renderSeparator = (item) => (
    // <View>
    //      {/* <Image style={{height:100,width:'100%',borderRadius:20,marginVertical:20,marginTop:0}} source={require('../asstes/Image/bank.png')} /> */}
  
    // </View>
    // );
  
    return (
      <View style={{flex: 1, }}>
        {/* <FlatList
        style={{
            alignSelf:'stretch'
        }}
        contentContainerStyle={{
            paddingHorizontal:20,
            alignSelf:'stretch'
        }}
          data={data}
          renderItem={renderItem}
          numColumns={2}
      
          showsVerticalScrollIndicator={false}
          ItemSeparatorComponent={renderSeparator}
        /> */}
      

      <MasonryList
            images={[
                // Can be used with different image object fieldnames.
                // Ex. source, source.uri, uri, URI, url, URL
                { uri: "https://luehangs.site/pic-chat-app-images/beautiful-blond-blonde-hair-478544.jpg" },
                // IMPORTANT: It is REQUIRED for LOCAL IMAGES
                // to include a dimensions field with the
                // actual width and height of the image or
                // it will throw an error.
                // { source: require("yourApp/image.png"),
                //     dimensions: { width: 1080, height: 1920 }
                // },
                // "width" & "height" is an alternative to the dimensions
                // field that will also be acceptable.
                // { source: require("yourApp/image.png"),
                //     width: 1080,
                //     height: 1920 },
                { source: { uri: "https://luehangs.site/pic-chat-app-images/beautiful-beautiful-women-beauty-40901.jpg" } },
                { uri: "https://luehangs.site/pic-chat-app-images/animals-avian-beach-760984.jpg",
                    // Optional: Adding a dimensions field with
                    // the actual width and height for REMOTE IMAGES
                    // will help improve performance.
                    dimensions: { width: 1080, height: 1920 } },
                { URI: "https://luehangs.site/pic-chat-app-images/beautiful-blond-fishnet-stockings-48134.jpg",
                    // Optional: Does not require an id for each
                    // image object, but is for best practices.
                    id: "blpccx4cn" },
                { url: "https://luehangs.site/pic-chat-app-images/beautiful-beautiful-woman-beauty-9763.jpg" },
                { URL: "https://luehangs.site/pic-chat-app-images/attractive-balance-beautiful-186263.jpg" },
            ]}
            // Version *2.14.0 update
            // onEndReached={() => {
            //     // add more images when scrolls reaches end
            // }}
        />


      </View>
    );
  };
  
  export default Api;
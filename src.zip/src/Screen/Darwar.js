import React,{useState} from 'react'
import { StyleSheet, Text, View, Image } from 'react-native'
import ImagePath from '../assets/ImagePath'
import Globl from '../common/Globl'

const Darwar = ({route}) => {
   
    return (
        <View style={{ flex: 1 }}>

            <View>
                <Image
                    style={{ width: 100, height: 100, alignSelf: 'center', borderRadius: 60, marginTop: 30,}}
                    source={ImagePath.usman} />

                <Text style={{ fontSize: 18 }}>{Globl.user}</Text>
                <Text style={{ fontSize: 18 }}>{Globl.age}</Text>

            </View>

        </View>
    )
}

export default Darwar

const styles = StyleSheet.create({})
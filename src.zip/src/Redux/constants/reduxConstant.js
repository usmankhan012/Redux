export const SUCCESS = 'SUCCESS';
export const LOADING = 'LOADING';
export const ERROR = 'ERROR';
export const NONE = 'NONE';


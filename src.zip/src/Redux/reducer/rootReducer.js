import {combineReducers} from 'redux';
import RootActions from './RootActions';

const rootReducer = combineReducers({
  RootActions,
});

export default rootReducer;
